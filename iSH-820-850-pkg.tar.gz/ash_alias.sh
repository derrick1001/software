alias go='/bin/sh /root/iSH-scripts/menu.sh'
alias howto='/bin/sh cat /root/iSH-scripts/README'



