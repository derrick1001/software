sleep 2
echo "admin"
sleep 2
echo "admin"
sleep 2
echo -e "platform configuration channel server set ip-address $1 directory disk1/820S-Builds/ filename 820S-12-0-HI-template.zip username RSI-Admin password can0py_BAM"
sleep 2
echo "platform configuration configuration-file import restore-point-1"
sleep 2
echo "yes"
sleep 15
echo "platform configuration configuration-file restore restore-point-1"
sleep 2
echo "yes"
sleep 2


