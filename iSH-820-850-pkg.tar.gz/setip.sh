#!/bin/sh

sleep 3
echo "admin"
sleep 3
echo "admin"
sleep 2
echo "platform management ip set ipv4-address 192.168.1.2"
sleep 2

