sleep 5
echo "admin"
sleep 5
echo "admin"
sleep 5
echo -e "platform software download channel server set server-ip $1 directory disk1/850C-Builds/850C-11-7 username RSI-Admin password can0py_BAM"
sleep 5
echo "platform software download version protocol ftp"
sleep 5
echo "yes"
sleep 5
echo "platform software download status show"
sleep 10
echo "platform software download status show"
sleep 10
echo "platform software download status show"
sleep 10
echo "platform software download status show"
sleep 10
echo "platform software download status show"
sleep 5
echo "platform software install version"
sleep 5
echo "yes"
sleep 5
echo "platform software install status show"
sleep 10
echo "platform software install status show"
sleep 10
echo "platform software install status show"
sleep 10
echo "platform software install status show"
sleep 10
echo "platform software install status show"
sleep 5
