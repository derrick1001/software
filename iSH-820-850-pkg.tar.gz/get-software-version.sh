sleep 3
echo "admin"
sleep 3
echo "admin"
sleep 2
echo "platform software show versions"
sleep 2
echo "quit"
sleep 2

