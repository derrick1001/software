sleep 2
echo "admin"
sleep 2
echo "admin"
sleep 2
echo  "radio slot 2 port 1"
sleep 2
echo "modem show status"
sleep 2
echo "atpc show rx-level"
sleep 2
echo "quit"

